(() => {
  const $ = id => document.getElementById(id);
  let expression = '';
  let mode = 'standard';
  let history = [];
  const exprEl = $('expression'), resultEl = $('result'), statusEl = $('status');
  const cleanDisplay = s => s.replace(/\*/g,'×').replace(/\//g,'÷').replace(/-/g,'−');
  function safeEval(raw) {
    let s = raw.replace(/×/g,'*').replace(/÷/g,'/').replace(/−/g,'-').replace(/%/g,'/100');
    if (!s.trim()) return 0;
    if (!/^[0-9+\-*/().\s]+$/.test(s)) throw Error('Invalid expression');
    // eslint-disable-next-line no-new-func
    const val = Function('"use strict"; return (' + s + ')')();
    if (!Number.isFinite(val)) throw Error('Cannot divide by zero');
    return val;
  }
  function format(n) {
    if (!Number.isFinite(n)) return 'Error';
    return Number.parseFloat(n.toPrecision(11)).toLocaleString('en-US',{maximumFractionDigits:8,useGrouping:true});
  }
  function render() {
    exprEl.textContent = expression ? cleanDisplay(expression) : '0';
    try { resultEl.textContent = expression ? format(safeEval(expression)) : '0'; }
    catch { resultEl.textContent = expression ? '…' : '0'; }
  }
  function add(v) {
    if (v === '.') {
      const last = expression.split(/[+\-*/()]/).pop();
      if (last.includes('.')) return;
    }
    if (/^[+\-*/]$/.test(v) && !expression && v !== '-') return;
    expression += v; render(); statusEl.textContent = 'Calculation in progress';
  }
  function equals() {
    try {
      const val = safeEval(expression);
      const answer = format(val);
      pushHistory(cleanDisplay(expression || '0'), answer);
      expression = String(val); render(); statusEl.textContent = 'Result calculated successfully';
    } catch { resultEl.textContent = 'Error'; statusEl.textContent = 'Check your calculation'; }
  }
  function pushHistory(exp, ans) {
    history.unshift({exp,ans});
    history = history.slice(0,12);
    drawHistory();
  }
  function drawHistory() {
    const list = $('historyList');
    if (!history.length) { list.innerHTML = '<p class="empty-state">Your calculations will appear here.</p>'; return; }
    list.innerHTML = history.map((h,i)=>`<button class="history-item" data-history="${i}"><span><small>${escapeHtml(h.exp)}</small><strong>${escapeHtml(h.ans)}</strong></span><span>↗</span></button>`).join('');
  }
  function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  document.querySelectorAll('[data-value]').forEach(b=>b.addEventListener('click',()=>add(b.dataset.value==='×'?'*':b.dataset.value==='÷'?'/':b.dataset.value==='−'?'-':b.dataset.value)));
  document.querySelectorAll('[data-action]').forEach(b=>b.addEventListener('click',()=>{
    const a=b.dataset.action;
    if(a==='clear'){expression='';statusEl.textContent='Ready for your next calculation';render();}
    if(a==='equals') equals();
    if(a==='sign'){if(expression.startsWith('-'))expression=expression.slice(1);else expression='-'+expression;render();}
  }));
  document.querySelectorAll('[data-fn]').forEach(b=>b.addEventListener('click',()=>{
    const fn=b.dataset.fn;
    if(fn==='sqrt') expression += 'Math.sqrt('; // replaced safely below by dedicated operation
    if(fn==='square') expression = '('+expression+')**2';
    if(['sin','cos','tan','log'].includes(fn)){
      try {const n=safeEval(expression);const v=fn==='sin'?Math.sin(n*Math.PI/180):fn==='cos'?Math.cos(n*Math.PI/180):fn==='tan'?Math.tan(n*Math.PI/180):Math.log10(n);expression=String(v);}
      catch {statusEl.textContent='Enter a valid number first';}
    }
    if(fn==='sqrt'){try{expression=String(Math.sqrt(safeEval(expression)));}catch{statusEl.textContent='Enter a valid number first';}}
    render();
  }));
  document.querySelectorAll('.mode-tab').forEach(b=>b.addEventListener('click',()=>{
    mode=b.dataset.mode;document.querySelectorAll('.mode-tab').forEach(t=>t.classList.toggle('active',t===b));
    $('calculatorPanel').classList.toggle('hidden',mode==='converter');
    $('converterPanel').classList.toggle('hidden',mode!=='converter');
    $('scientificKeys').classList.toggle('hidden',mode!=='scientific');
    $('modeLabel').textContent=mode==='scientific'?'SCIENTIFIC CALCULATOR':mode==='converter'?'UNIT CONVERTER':'STANDARD CALCULATOR';
  }));
  $('historyToggle').addEventListener('click',()=>{$('historyPanel').classList.toggle('hidden');if(!$('historyPanel').classList.contains('hidden'))$('historyPanel').scrollIntoView({behavior:'smooth',block:'nearest'});});
  $('clearHistory').addEventListener('click',()=>{history=[];drawHistory();});
  $('historyList').addEventListener('click',e=>{const b=e.target.closest('[data-history]');if(!b)return;expression=String(safeEval(history[Number(b.dataset.history)].exp.replace(/×/g,'*').replace(/÷/g,'/').replace(/−/g,'-')));render();});
  $('copyResult').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(resultEl.textContent);statusEl.textContent='Result copied to clipboard';}catch{statusEl.textContent='Clipboard is not available in this browser';}});
  document.addEventListener('keydown',e=>{
    if(/^[0-9.]$/.test(e.key))add(e.key);
    else if(e.key==='+')add('+'); else if(e.key==='-')add('-'); else if(e.key==='*')add('*'); else if(e.key==='/'){e.preventDefault();add('/');}
    else if(e.key==='Enter'||e.key==='='){e.preventDefault();equals();}
    else if(e.key==='Backspace'){expression=expression.slice(0,-1);render();}
    else if(e.key==='Escape'){expression='';render();}
  });
  const units={
    length:{Meter:1,Kilometer:1000,Centimeter:.01,Millimeter:.001,Mile:1609.344,Foot:.3048,Inch:.0254},
    weight:{Kilogram:1,Gram:.001,Pound:.45359237,Ounce:.0283495},
    temperature:{Celsius:'C',Fahrenheit:'F',Kelvin:'K'}
  };
  function setupUnits(){const type=$('convertType').value, from=$('fromUnit'),to=$('toUnit');const keys=Object.keys(units[type]);from.innerHTML=to.innerHTML=keys.map(k=>`<option>${k}</option>`).join('');if(type==='length'){from.value='Meter';to.value='Kilometer';}else if(type==='weight'){from.value='Kilogram';to.value='Gram';}else{from.value='Celsius';to.value='Fahrenheit';}convert();}
  function convertTemp(v,from,to){let c=from==='Fahrenheit'?(v-32)*5/9:from==='Kelvin'?v-273.15:v;return to==='Fahrenheit'?c*9/5+32:to==='Kelvin'?c+273.15:c;}
  function convert(){const type=$('convertType').value,from=$('fromUnit').value,to=$('toUnit').value,v=Number($('convertValue').value||0);let out;if(type==='temperature')out=convertTemp(v,from,to);else out=v*units[type][from]/units[type][to];$('convertResult').textContent=format(out);}
  $('convertType').addEventListener('change',setupUnits);['fromUnit','toUnit','convertValue'].forEach(id=>$(id).addEventListener('input',convert));$('swapUnits').addEventListener('click',()=>{const f=$('fromUnit'),t=$('toUnit'),v=f.value;f.value=t.value;t.value=v;convert();});
  setupUnits();render();
})();