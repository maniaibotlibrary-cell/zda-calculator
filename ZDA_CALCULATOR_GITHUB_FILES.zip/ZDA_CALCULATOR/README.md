# ZDA Calculator

A responsive calculator web app with a dark neon interface, standard arithmetic, scientific functions, unit conversion, calculation history, keyboard support, and installable PWA setup.

## Files
- `index.html` — app layout
- `style.css` — responsive styling
- `app.js` — calculator logic
- `manifest.json` — installable app metadata
- `service-worker.js` — basic offline caching
- `icon.svg` — original ZDA app icon

## Deploy to GitHub + Vercel
1. Create a new GitHub repository named `zda-calculator`.
2. Upload the contents of this folder (not the ZIP itself) to the repository root.
3. In Vercel, choose **Add New → Project**, import `zda-calculator`.
4. Framework preset: **Other**. Build command: leave blank. Output directory: `.` (or leave default if Vercel detects static files).
5. Press **Deploy**. Vercel will provide a public URL.

## Add to Android Home Screen
Open the deployed URL in Chrome → tap ⋮ → **Add to Home screen** or **Install app**.

## Notes
This is a static web app and does not need an API key. Scientific trigonometry uses degrees. Unit conversions run locally in the browser.
